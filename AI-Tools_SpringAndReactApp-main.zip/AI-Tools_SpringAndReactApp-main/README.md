We will deploy this apps on AWS
