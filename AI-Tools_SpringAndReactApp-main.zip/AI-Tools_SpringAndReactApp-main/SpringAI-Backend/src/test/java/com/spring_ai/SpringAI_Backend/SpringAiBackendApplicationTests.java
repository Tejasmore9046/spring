package com.spring_ai.SpringAI_Backend;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringAiBackendApplicationTests {

	@Test
	void contextLoads() {
	}

}
